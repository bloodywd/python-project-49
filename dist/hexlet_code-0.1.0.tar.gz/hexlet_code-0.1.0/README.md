### Hexlet tests and linter status:
[![Actions Status](https://github.com/bloodywd/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/bloodywd/python-project-49/actions)
<a href="https://codeclimate.com/github/bloodywd/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/fce8f3870b6a02de345e/maintainability" /></a>